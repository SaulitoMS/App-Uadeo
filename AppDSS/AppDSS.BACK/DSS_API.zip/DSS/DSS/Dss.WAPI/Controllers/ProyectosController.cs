﻿using DSS.WAPI.Contexts;
using DSS.WAPI.Entities;
using DSS.WAPI.Util;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Dss.WAPI.Controllers
{
    [Route("api/DSS/[controller]")]
    [ApiController]
    public class ProyectosController : ControllerBase
    {
        private DssContext bd;

        //Inyección de Dependencias
        public ProyectosController(DssContext bd)
        {
            this.bd = bd;
        }

        //Get: Obtiene la Lista de Proyectos
        [HttpGet]
        public async Task<ActionResult<Resultado<IEnumerable<Proyectos>>>> Get()
        {
            try
            {
                //Consulta la lista
                IEnumerable<Proyectos> lstObj = await bd.Proyectos.ToListAsync();

                //Valida si la encontró
                if (lstObj == null)
                    return new Resultado<IEnumerable<Proyectos>>(false, "La lista de Proyectos está vacía", null);
                else
                    return new Resultado<IEnumerable<Proyectos>>(true, "La lista de Proyectos fue obtenida con éxito", lstObj);
            }
            catch (Exception ex)
            {
                //Verifica si se produce error
                return new Resultado<IEnumerable<Proyectos>>(false, String.Format("Error al consultar la lista de Proyectos. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }

        //Get(Id): Obtiene un Proyecto por Id
        [HttpGet("{iId}", Name = "GetProyecto")]
        public async Task<ActionResult<Resultado<Proyectos>>> Get(int iId)
        {
            try
            {
                //Consulta el objeto
                Proyectos obj = await bd.Proyectos.Where(tbl => tbl.ID_Proy == iId).FirstOrDefaultAsync();

                //Valida si lo encontró
                if (obj == null)
                    return new Resultado<Proyectos>(false, "El Proyecto no se encontró", null);
                else
                    return new Resultado<Proyectos>(true, "El Proyecto fue obtenido con éxito", obj);
            }
            catch (Exception ex)
            {
                //Verifica si se produce error
                return new Resultado<Proyectos>(false, String.Format("Error al consultar el Proyecto. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }

        //Post: Agrega un Proyecto Nuevo
        [HttpPost]
        public async Task<ActionResult<Resultado<Proyectos>>> Post([FromBody] Proyectos obj)
        {
            try
            {
                //Consulta el objeto
                Proyectos objAux = await bd.Proyectos.Where(tbl => tbl.ID_Proy == obj.ID_Proy).FirstOrDefaultAsync();

                //Valida si existe
                if (obj != null)
                {
                    return new Resultado<Proyectos>(false, "El Proyecto que desea registrar ya existe.", null);
                }
                else
                {
                    //Registra objeto
                    await bd.Proyectos.AddAsync(obj);
                    await bd.SaveChangesAsync();

                    Resultado<Proyectos> res = new Resultado<Proyectos>(true, "El Proyecto fue registrado con éxito.", obj);
                    return new CreatedAtRouteResult("GetProyecto", new { iId = obj.ID_Proy }, res);
                }
            }
            catch (Exception ex)
            {
                //Verifica si se produce error
                return new Resultado<Proyectos>(false, String.Format("Error al registrar el Proyecto. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }

        //Put: Modifica un Proyecto Existente
        [HttpPut("{iId}")]
        public async Task<ActionResult<Resultado<Proyectos>>> Put(int iId, [FromBody] Proyectos obj)
        {
            try
            {
                //Verifica si el Usuario existe
                Proyectos objAux = await bd.Proyectos.Where(x => x.ID_Proy == iId).FirstOrDefaultAsync();

                //No existe
                if (obj == null)
                {
                    return new Resultado<Proyectos>(false, "El Proyecto que desea modificar no existe.", null);
                }
                //Si existe
                else
                {
                    //Valida que no modifiquen la Clave
                    if (iId != obj.ID_Proy)
                    {
                        return new Resultado<Proyectos>(false, "No puede modificar la clave del Proyecto.", null);
                    }
                    else
                    {
                        //Actualiza el Usuario
                        bd.Entry(objAux).State = EntityState.Detached;
                        bd.Entry(obj).State = EntityState.Modified;
                        await bd.SaveChangesAsync();
                        return new Resultado<Proyectos>(true, "El Proyecto fue modificado con éxito.", obj);
                    }
                }
            }
            catch (Exception ex)
            {
                //Verifica si se produce error al consultar
                return new Resultado<Proyectos>(false, String.Format("Error al modificiar el Proyecto. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }


        //Delete: Borra un Proyecto Existente
        [HttpDelete("{iId}")]
        public async Task<ActionResult<Resultado<Proyectos>>> Delete(int iId)
        {
            try
            {
                //Verifica si el Usuario existe
                Proyectos objAux = await bd.Proyectos.Where(x => x.ID_Proy == iId).FirstOrDefaultAsync();

                //Si no existe
                if (objAux == null)
                {
                    return new Resultado<Proyectos>(false, "El Proyecto que desea borrar no existe.", null);
                }
                //Si existe
                else
                {
                    //Elimina el usuario
                    bd.Proyectos.Remove(objAux);
                    await bd.SaveChangesAsync();

                    return new CreatedAtRouteResult("GetProyecto", new { iId = iId });
                }
            }
            catch (Exception ex)
            {
                //Verifica si se produce error al consultar
                return new Resultado<Proyectos>(false, String.Format("Error al borrar el Proyecto. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }


    }
}
