﻿using DSS.WAPI.Contexts;
using DSS.WAPI.Entities;
using DSS.WAPI.Util;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DSS.WAPI.Controllers
{
    [Route("api/DSS/[controller]")]
    [ApiController]
    public class MatrizController : ControllerBase
    {
        private DssContext bd;

        // Inyeccion de dependencias
        public MatrizController(DssContext bd)
        {
            this.bd = bd;
        }

        //Get: Obtiene la lista de proyectos
        [HttpGet]
        public async Task<ActionResult<Resultado<IEnumerable<Matriz>>>> Get()
        {
            try
            {
                IEnumerable<Matriz> lstObj = await bd.Matriz.ToListAsync();

                if (lstObj == null)
                {
                    return new Resultado<IEnumerable<Matriz>>(false, "La lista de Matriz está vacía", null);
                }
                else
                {
                    return new Resultado<IEnumerable<Matriz>>(true, "La lista de Matriz fue obtenida con exito", lstObj);
                }

            }
            catch (Exception ex)
            {
                return new Resultado<IEnumerable<Matriz>>(false, String.Format("Error al consultar la lista de Matriz.Mensaje del Servidor:{0}", ex.Message), null);
            }

        }

        //Get(Id): Obtiene un proyecto por Id
        [HttpGet("{iId}", Name = "GetMatriz")]
        public async Task<ActionResult<Resultado<Matriz>>> Get(int iId)
        {
            try
            {
                //Consulta el objeto
                Matriz obj = await bd.Matriz.Where(tbl => tbl.ID_Matriz == iId).FirstOrDefaultAsync();

                //Valida si lo encontró
                if (obj == null)
                    return new Resultado<Matriz>(false, "La Matriz no se encontró", null);
                else
                    return new Resultado<Matriz>(true, "La Matriz no se encontró", obj);
            }
            catch (Exception ex)
            {
                //Verifica si se produce error
                return new Resultado<Matriz>(false, String.Format("Error al consultar la Matriz. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }
        //Post: Agrega un proyecto nuevo
        [HttpPost]
        public async Task<ActionResult<Resultado<Matriz>>> Post([FromBody] Matriz obj)
        {
            try
            {
                //Consulta el objeto
                Matriz objAux = await bd.Matriz.Where(tbl => tbl.ID_Matriz == obj.ID_Matriz).FirstOrDefaultAsync();

                //Valida si existe
                if (obj != null)
                {
                    return new Resultado<Matriz>(false, "La Matriz que desea registrar ya existe.", null);
                }
                else
                {
                    //Registra objeto
                    await bd.Matriz.AddAsync(obj);
                    await bd.SaveChangesAsync();

                    Resultado<Matriz> res = new Resultado<Matriz>(true, "La Matriz fue registrado con éxito.", obj);
                    return new CreatedAtRouteResult("GetMatriz", new { iId = obj.ID_Matriz }, res);
                }
            }
            catch (Exception ex)
            {
                //Verifica si se produce error
                return new Resultado<Matriz>(false, String.Format("Error al registrar la Matriz. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }
        //Put: Modifica un proyecto Existente

        //Delete: Borra un proyecto Existente
    }
}
