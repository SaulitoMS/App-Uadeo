﻿using DSS.WAPI.Contexts;
using DSS.WAPI.Entities;
using DSS.WAPI.Util;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DSS.WAPI.Controllers
{
    [Route("api/DSS/[controller]")]
    [ApiController]
    public class AlternativasController : ControllerBase
    {
        private DssContext bd;

        // Inyeccion de dependencias
        public AlternativasController(DssContext bd)
        {
            this.bd = bd;
        }

        //Get: Obtiene la lista de proyectos
        [HttpGet]
        public async Task<ActionResult<Resultado<IEnumerable<Alternativas>>>> Get()
        {
            try
            {
                IEnumerable<Alternativas> lstObj = await bd.Alternativas.ToListAsync();

                if (lstObj == null)
                {
                    return new Resultado<IEnumerable<Alternativas>>(false, "La lista de Alternativas está vacía", null);
                }
                else
                {
                    return new Resultado<IEnumerable<Alternativas>>(true, "La lista de Alternativas fue obtenida con exito", lstObj);
                }

            }
            catch (Exception ex)
            {
                return new Resultado<IEnumerable<Alternativas>>(false, String.Format("Error al consultar la lista de Alternativas.Mensaje del Servidor:{0}", ex.Message), null);
            }

        }

        //Get(Id): Obtiene un proyecto por Id
        [HttpGet("{iId}", Name = "GetAlternativas")]
        public async Task<ActionResult<Resultado<Alternativas>>> Get(int iId)
        {
            try
            {
                //Consulta el objeto
                Alternativas obj = await bd.Alternativas.Where(tbl => tbl.ID_Alt == iId).FirstOrDefaultAsync();

                //Valida si lo encontró
                if (obj == null)
                    return new Resultado<Alternativas>(false, "La Alternativa no se encontró", null);
                else
                    return new Resultado<Alternativas>(true, "La Alternativa fue obtenido con éxito", obj);
            }
            catch (Exception ex)
            {
                //Verifica si se produce error
                return new Resultado<Alternativas>(false, String.Format("Error al consultar la Alternativa. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }
        //Post: Agrega un proyecto nuevo
        [HttpPost]
        public async Task<ActionResult<Resultado<Alternativas>>> Post([FromBody] Alternativas obj)
        {
            try
            {
                //Consulta el objeto
                Alternativas objAux = await bd.Alternativas.Where(tbl => tbl.ID_Alt == obj.ID_Alt).FirstOrDefaultAsync();

                //Valida si existe
                if (obj != null)
                {
                    return new Resultado<Alternativas>(false, "La Alternativa que desea registrar ya existe.", null);
                }
                else
                {
                    //Registra objeto
                    await bd.Alternativas.AddAsync(obj);
                    await bd.SaveChangesAsync();

                    Resultado<Alternativas> res = new Resultado<Alternativas>(true, "La Alternativa fue registrado con éxito.", obj);
                    return new CreatedAtRouteResult("GetAlternativa", new { iId = obj.ID_Alt }, res);
                }
            }
            catch (Exception ex)
            {
                //Verifica si se produce error
                return new Resultado<Alternativas>(false, String.Format("Error al registrar la Alternativa. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }
        //Put: Modifica un proyecto Existente

        //Delete: Borra un proyecto Existente
    }
}
