/*--------Libraries-----------*/
using DSS.WAPI.Contexts;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Serialization;


/*--------utility-----------*/
var builder = WebApplication.CreateBuilder(args);
var provider = builder.Services.BuildServiceProvider();

//Config
var cnf = provider.GetRequiredService<IConfiguration>();

//Internal variables
var MyAllowSpecificOrigins = "_myAllowSpecificOrigins";
var cnxDSS = builder.Configuration.GetConnectionString("cnxDSS");


/*--------service-----------*/

//Define Context (PostgreSQL)
builder.Services.AddDbContext<DssContext>(
	options =>
	{
		options.UseSqlServer(cnxDSS);
	}
);

//NewtonSoft
builder.Services.AddControllers().AddNewtonsoftJson(
	options =>
	{
		options.SerializerSettings.ContractResolver = new DefaultContractResolver();
		options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
	}
);

//Cors
builder.Services.AddCors(
	options =>
	{
		options.AddPolicy(
			name: MyAllowSpecificOrigins,
			policy =>
			{
				policy.WithOrigins();
				policy.AllowAnyHeader();
				policy.AllowAnyMethod();
				policy.AllowAnyOrigin();
			});
	});



/*--------app-----------*/
var app = builder.Build();

app.MapGet("/", () => "Hello World!");

app.UseHttpsRedirection();
app.UseRouting();
app.UseCors(MyAllowSpecificOrigins);
app.UseAuthorization();

app.UseEndpoints(
	endpoints =>
	{
		endpoints.MapControllers();
	}
);

app.Run();
