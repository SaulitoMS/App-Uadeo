﻿using System.ComponentModel.DataAnnotations;

namespace DSS.WAPI.Entities
{
    public class Proyectos
    {
        [Required]
        public int ID_Proy { get; set; }
        [Required]
        public string Nombre_Proy { get; set; }

        public string Objetivo_Proy { get; set; }

    }
}
