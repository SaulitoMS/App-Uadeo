﻿using System.ComponentModel.DataAnnotations;

namespace DSS.WAPI.Entities
{
    public class Matriz
    {
        [Required]
        public int ID_Matriz { get; set; }
        [Required]
        public int Valor_Matriz { get; set; }
        [Required]
        public int ID_Proy { get; set; }
        [Required]
        public int ID_Alt { get; set; }
        [Required]
        public int ID_Crit { get; set; }
    }
}

