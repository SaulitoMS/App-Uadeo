﻿using System.ComponentModel.DataAnnotations;

namespace DSS.WAPI.Entities
{
    public class Alternativas
    {
        [Required]
        public int ID_Alt { get; set; }
        [Required]
        public string Nombre_Alt { get; set; }

        public string Descripcion_Alt { get; set; }

        [Required]
        public int ID_Proy { get; set; }
    }
}
