﻿using DSS.WAPI.Entities;
using Microsoft.EntityFrameworkCore;

namespace DSS.WAPI.Contexts
{
    public class DssContext : DbContext
    {
        public DbSet<Proyectos> Proyectos { get; set; }
        public DbSet<Alternativas> Alternativas { get; set; }
        public DbSet<Criterios> Criterios { get; set; }
        public DbSet<Matriz> Matriz { get; set; }
        public DbSet<Scores> Scores { get; set; }

        public DssContext(DbContextOptions<DssContext> options) : base(options) 
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Proyectos>(
                tbl =>
                {
                    tbl.HasKey(tbl => new { tbl.ID_Proy });
                }
                );

            modelBuilder.Entity<Alternativas>(
                tbl =>
                {
                    tbl.HasKey(tbl => new { tbl.ID_Alt });
                }
                );

            modelBuilder.Entity<Criterios>(
                tbl =>
                {
                    tbl.HasKey(tbl => new { tbl.ID_Crit });
                }
                );

            modelBuilder.Entity<Matriz>(
                tbl =>
                {
                    tbl.HasKey(tbl => new { tbl.ID_Matriz });
                }
                );

            modelBuilder.Entity<Scores>(
                tbl =>
                {
                    tbl.HasKey(tbl => new { tbl.ID_Score });
                }
                );
        }
    }
}
