﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSSEscoringBueno.ClasesGenericas
{
    internal class CriteriosModels
    {
        
        public int ID_Crit { get; set; }
        
        public string Nombre_Crit { get; set; }

        public string Descripcion_Crit { get; set; }
        
        public int Peso_Crit { get; set; }
        
        public int ID_Proy { get; set; }
    }
}
