﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DSSEscoringBueno.Catalogos
{
    public partial class Criterios : Form
    {
        public Criterios()
        {
            InitializeComponent();
        }

        private void txtIdProy_TextChanged(object sender, EventArgs e)
        {

        }

        private void Criterios_Load(object sender, EventArgs e)
        {

        }

        private void txtIdProy_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtId.Focus();
            }
        }

        private void txtId_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtNombre.Focus();
            }
        }

        private void txtNombre_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtObjetivo.Focus();
            }
        }

        private void txtIdProy_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                
                e.Handled = true;
            }
        }

        private void txtId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {

                e.Handled = true;
            }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            txtIdProy.Text = "";
            txtId.Text = "";
            txtNombre.Text = "";
            txtObjetivo.Text = "";
        }
    }
}
