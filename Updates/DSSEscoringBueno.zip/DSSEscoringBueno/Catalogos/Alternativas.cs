﻿using DSSEscoringBueno.ClasesGenericas;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DSSEscoringBueno.Catalogos
{
    public partial class Alternativas : Form
    {
        public Alternativas()
        {
            InitializeComponent();
        }

        private void Alternativas_Load(object sender, EventArgs e)
        {

        }
        private static readonly HttpClient client = new HttpClient
        {
            BaseAddress = new Uri("https://localhost:7147/api/DSS/Alternativas/")
        };


        //necesario para get
        public class Resultado<T>
        {
            public bool Status { get; set; }        
            public string Message { get; set; }     
            public T Data { get; set; }             
        }


        //get
        private async Task traerAlternativas()
        {
            try
            {
                
                HttpResponseMessage response = await client.GetAsync("");

                if (response.IsSuccessStatusCode)
                {
                    string jsonResponse = await response.Content.ReadAsStringAsync();
                   

                    
                    var resultado = JsonConvert.DeserializeObject<Resultado<IEnumerable<AlternativasModels>>>(jsonResponse);

                    if (resultado != null && resultado.Status)
                    {
                        if (resultado.Data != null) 
                        {
                            dataGridView1.DataSource = null;
                            dataGridView1.DataSource = resultado.Data.ToList();
                            dataGridView1.AutoResizeColumns();
                            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                        }
                        else
                        {
                            MessageBox.Show("No se encontraron datos para mostrar.");
                        }
                    }
                    else
                    {
                        MessageBox.Show($"Error del servidor: {resultado?.Message ?? "Error desconocido"}");
                    }
                }
                else
                {
                    string contenidoError = await response.Content.ReadAsStringAsync();
                    MessageBox.Show($"Error en la petición: {response.StatusCode} - {response.ReasonPhrase}\nContenido: {contenidoError}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al traer Alternativas: {ex.Message}");
                Console.WriteLine($"Error detallado: {ex}");
            }
        }
           
            
        

        //post 
        private async Task CrearAlternativa()
        {
            try
            {

                var nuevaAlternativa = new AlternativasModels
                {
                    ID_Alt = int.Parse(txtId.Text),
                    Nombre_Alt = txtNombre.Text,
                    Descripcion_Alt = txtObjetivo.Text,
                    ID_Proy = int.Parse(txtIdProy.Text)
                };


                var content = new StringContent(JsonConvert.SerializeObject(nuevaAlternativa), Encoding.UTF8, "application/json");


                var response = await client.PostAsync("Alternativas", content);
                response.EnsureSuccessStatusCode();

                MessageBox.Show("Alternativa creada con éxito.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al crear la alternativa: {ex.Message}");
                Console.WriteLine(ex.Message);
            }
        }
        private async Task ModificarAlternativa(int id)
        {
            try
            {

            }
            catch ( Exception ex)
            {
                MessageBox.Show($"Error de conexión: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
        }

        //delete
        private async Task<bool> EliminarAlternativa(int id)
        {
            try
            {
                var response = await client.DeleteAsync($"{id}");
                var contenido = await response.Content.ReadAsStringAsync();
                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Alternativa eliminada exitosamente", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return true;
                }
                else 
                {
                    var error = await response.Content.ReadAsStringAsync();
                    MessageBox.Show($"Error al eliminar: {error}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error de conexión: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }



        private void txtProy_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
               
                e.Handled = true;
            }
           
        }

        private void txtId_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                
                e.Handled = true;
            }
        }

        private void txtProy_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtId.Focus();
            }
        }

        private void txtId_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtNombre.Focus();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtIdProy_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtIdProy_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtId.Focus();
            }
        }

        private void txtId_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtNombre.Focus();
            }
        }

        private void txtId_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                
                e.Handled = true;
            }
        }

        private void txtIdProy_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                
                e.Handled = true;
            }
        }

        private void txtNombre_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtObjetivo.Focus();
            }
        }

        private void txtObjetivo_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtIdProy.Text = "";
            txtId.Text = "";
            txtNombre.Text = "";
            txtObjetivo.Text = "";

        }

        private async void btnGuardar_Click(object sender, EventArgs e)
        {
            await CrearAlternativa();
            await traerAlternativas();
        }

        private async void btnEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtId.Text))
            {
                MessageBox.Show("Por favor ingrese un ID válido", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            int id = int.Parse(txtId.Text);
           

            if (MessageBox.Show("¿Está seguro que desea eliminar esta alternativa?", "Confirmar eliminación",
       MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                if (await EliminarAlternativa(id))
                {
                    txtId.Clear();

                    await traerAlternativas();

                }
                
            }

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            MenuPrincipal menuPrincipal = new MenuPrincipal();

            menuPrincipal.Show();

            this.Close();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtId.Text))
            {
                MessageBox.Show("Por favor ingrese un ID válido para editar el valor", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }

        private async void btnConsultar_Click(object sender, EventArgs e)
        {
            await traerAlternativas();
        }
    }
}
