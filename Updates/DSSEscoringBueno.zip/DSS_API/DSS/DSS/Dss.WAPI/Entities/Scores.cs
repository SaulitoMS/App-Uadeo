﻿using System.ComponentModel.DataAnnotations;

namespace DSS.WAPI.Entities
{
    public class Scores
    {
        [Required]
        public int ID_Score { get; set; }
        [Required]
        public int Score {  get; set; }
        [Required]
        public int ID_Proy { get; set; }
        [Required]
        public int ID_Alt { get; set; }
    }
}
