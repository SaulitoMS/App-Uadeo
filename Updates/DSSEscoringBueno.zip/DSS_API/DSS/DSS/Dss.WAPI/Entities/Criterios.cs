﻿using System.ComponentModel.DataAnnotations;

namespace DSS.WAPI.Entities
{
    public class Criterios
    {
        [Required]
        public int ID_Crit { get; set; }
        [Required]
        public string Nombre_Crit { get; set; }

        public string Descripcion_Crit { get; set; }
        [Required]
        public int Peso_Crit { get; set; }
        [Required]
        public int ID_Proy { get; set; }
    }
}

