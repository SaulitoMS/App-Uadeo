﻿namespace DSS.WAPI.Util
{
    public class Resultado<T>
    {
        public bool Status;
        public string Message;
        public T Data { get; set; }

        //Constructor
        public Resultado(bool status, string message, T data)
        {
          this.Status = status;
          this.Message = message;
          this.Data = data;
        }
    }
}
