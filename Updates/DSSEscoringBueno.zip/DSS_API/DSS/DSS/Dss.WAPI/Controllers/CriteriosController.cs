﻿using DSS.WAPI.Contexts;
using DSS.WAPI.Entities;
using DSS.WAPI.Util;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DSS.WAPI.Controllers
{
    [Route("api/DSS/[controller]")]
    [ApiController]
    public class CriteriosController : ControllerBase
    {
        private DssContext bd;

        // Inyeccion de dependencias
        public CriteriosController(DssContext bd)
        {
            this.bd = bd;
        }

        //Get: Obtiene la lista de Criterios
        [HttpGet]
        public async Task<ActionResult<Resultado<IEnumerable<Criterios>>>> Get()
        {
            try
            {
                IEnumerable<Criterios> lstObj = await bd.Criterios.ToListAsync();

                if (lstObj == null)
                {
                    return new Resultado<IEnumerable<Criterios>>(false, "La lista de Criterios está vacía", null);
                }
                else
                {
                    return new Resultado<IEnumerable<Criterios>>(true, "La lista de Criterios fue obtenida con exito", lstObj);
                }

            }
            catch (Exception ex)
            {
                return new Resultado<IEnumerable<Criterios>>(false, String.Format("Error al consultar la lista de Criterios.Mensaje del Servidor:{0}", ex.Message), null);
            }

        }

        //Get(Id): Obtiene un Criterio por Id
        [HttpGet("{iId}", Name = "GetCriterios")]
        public async Task<ActionResult<Resultado<Criterios>>> Get(int iId)
        {
            try
            {
                //Consulta el objeto
                Criterios obj = await bd.Criterios.Where(tbl => tbl.ID_Crit == iId).FirstOrDefaultAsync();

                //Valida si lo encontró
                if (obj == null)
                    return new Resultado<Criterios>(false, "El Criterio no se encontró", null);
                else
                    return new Resultado<Criterios>(true, "El Criterio fue obtenido con éxito", obj);
            }
            catch (Exception ex)
            {
                //Verifica si se produce error
                return new Resultado<Criterios>(false, String.Format("Error al consultar el Criterio. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }
        //Post: Agrega un Criterio nuevo
        [HttpPost]
        public async Task<ActionResult<Resultado<Criterios>>> Post([FromBody] Criterios obj)
        {
            try
            {
                //Consulta el objeto
                Criterios objAux = await bd.Criterios.Where(tbl => tbl.ID_Crit == obj.ID_Crit).FirstOrDefaultAsync();

                //Valida si existe
                if (obj == null)
                {
                    return new Resultado<Criterios>(false, "El Criterio que desea registrar ya existe.", null);
                }
                else
                {
                    //Registra objeto
                    await bd.Criterios.AddAsync(obj);
                    await bd.SaveChangesAsync();

                    Resultado<Criterios> res = new Resultado<Criterios>(true, "El Criterio fue registrado con éxito.", obj);
                    return new CreatedAtRouteResult("GetCriterios", new { iId = obj.ID_Crit }, res);
                }
            }
            catch (Exception ex)
            {
                //Verifica si se produce error
                return new Resultado<Criterios>(false, String.Format("Error al registrar el Criterio. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }

        //Put: Modifica un Criterio Existente
        [HttpPut("{iId}")]
        public async Task<ActionResult<Resultado<Criterios>>> Put(int iId, [FromBody] Criterios obj)
        {
            try
            {
                //Verifica si el Usuario existe
                Criterios objAux = await bd.Criterios.Where(x => x.ID_Crit == iId).FirstOrDefaultAsync();

                //No existe
                if (obj == null)
                {
                    return new Resultado<Criterios>(false, "El Criterio que desea modificar no existe.", null);
                }
                //Si existe
                else
                {
                    //Valida que no modifiquen la Clave
                    if (iId != obj.ID_Crit)
                    {
                        return new Resultado<Criterios>(false, "No puede modificar la clave del Criterio.", null);
                    }
                    else
                    {
                        //Actualiza el Usuario
                        bd.Entry(objAux).State = EntityState.Detached;
                        bd.Entry(obj).State = EntityState.Modified;
                        await bd.SaveChangesAsync();
                        return new Resultado<Criterios>(true, "El Criterio fue modificado con éxito.", obj);
                    }
                }
            }
            catch (Exception ex)
            {
                //Verifica si se produce error al consultar
                return new Resultado<Criterios>(false, String.Format("Error al modificiar el Criterio. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }


        //Delete: Borra un Criterio Existente
        [HttpDelete("{iId}")]
        public async Task<ActionResult<Resultado<Criterios>>> Delete(int iId)
        {
            try
            {
                //Verifica si el Usuario existe
                Criterios objAux = await bd.Criterios.Where(x => x.ID_Crit == iId).FirstOrDefaultAsync();

                //Si no existe
                if (objAux == null)
                {
                    return new Resultado<Criterios>(false, "El Criterio que desea borrar no existe.", null);
                }
                //Si existe
                else
                {
                    //Elimina el usuario
                    bd.Criterios.Remove(objAux);
                    await bd.SaveChangesAsync();

                    return new CreatedAtRouteResult("GetCriterio", new { iId = iId });
                }
            }
            catch (Exception ex)
            {
                //Verifica si se produce error al consultar
                return new Resultado<Criterios>(false, String.Format("Error al borrar el Criterio. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }
        
    }
}