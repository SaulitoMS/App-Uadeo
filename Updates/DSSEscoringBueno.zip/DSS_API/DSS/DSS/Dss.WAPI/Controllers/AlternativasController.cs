﻿using DSS.WAPI.Contexts;
using DSS.WAPI.Entities;
using DSS.WAPI.Util;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DSS.WAPI.Controllers
{
    [Route("api/DSS/[controller]")]
    [ApiController]
    public class AlternativasController : ControllerBase
    {
        private DssContext bd;

        // Inyeccion de dependencias
        public AlternativasController(DssContext bd)
        {
            this.bd = bd;
        }



        //Get: Obtiene la lista de Alternativas
        [HttpGet]
        public async Task<ActionResult<Resultado<IEnumerable<Alternativas>>>> Get()
        {
            try
            {
                IEnumerable<Alternativas> lstObj = await bd.Alternativas.ToListAsync();

                if (lstObj == null)
                {
                    return new Resultado<IEnumerable<Alternativas>>(false, "La lista de Alternativas está vacía", null);
                }
                else
                {
                    return new Resultado<IEnumerable<Alternativas>>(true, "La lista de Alternativas fue obtenida con exito", lstObj);
                }

            }
            catch (Exception ex)
            {
                return new Resultado<IEnumerable<Alternativas>>(false, String.Format("Error al consultar la lista de Alternativas.Mensaje del Servidor:{0}", ex.Message), null);
            }

        }

        //Get(Id): Obtiene una Alternativa por Id
        [HttpGet("{iId}", Name = "GetAlternativas")]
        public async Task<ActionResult<Resultado<Alternativas>>> Get(int iId)
        {
            try
            {
                //Consulta el objeto
                Alternativas obj = await bd.Alternativas.Where(tbl => tbl.ID_Alt == iId).FirstOrDefaultAsync();

                //Valida si lo encontró
                if (obj == null)
                    return new Resultado<Alternativas>(false, "La Alternativa no se encontró", null);
                else
                    return new Resultado<Alternativas>(true, "La Alternativa fue obtenido con éxito", obj);
            }
            catch (Exception ex)
            {
                //Verifica si se produce error
                return new Resultado<Alternativas>(false, String.Format("Error al consultar la Alternativa. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }
        //Post: Agrega una Alternativa nueva
        [HttpPost]
        public async Task<ActionResult<Resultado<Alternativas>>> Post([FromBody] Alternativas obj)
        {
            try
            {
                //Consulta el objeto
                Alternativas objAux = await bd.Alternativas.Where(tbl => tbl.ID_Alt == obj.ID_Alt).FirstOrDefaultAsync();

                //Valida si existe
                if (objAux != null)
                {
                    return new Resultado<Alternativas>(false, "La Alternativa que desea registrar ya existe.", null);
                }
                else
                {
                    //Registra objeto
                    await bd.Alternativas.AddAsync(obj);
                    await bd.SaveChangesAsync();

                    Resultado<Alternativas> res = new Resultado<Alternativas>(true, "La Alternativa fue registrado con éxito.", obj);
                    return new CreatedAtRouteResult("GetAlternativas", new { iId = obj.ID_Alt }, res);
                }
            }
            catch (Exception ex)
            {
                //Verifica si se produce error
                return new Resultado<Alternativas>(false, String.Format("Error al registrar la Alternativa. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }
        //Put: Modifica una Alternativa Existente
        [HttpPut("{iId}")]
        public async Task<ActionResult<Resultado<Alternativas>>> Put(int iId, [FromBody] Alternativas obj)
        {
            try
            {
                //Verifica si el Usuario existe
                Alternativas objAux = await bd.Alternativas.Where(x => x.ID_Alt == iId).FirstOrDefaultAsync();

                //No existe
                if (obj == null)
                {
                    return new Resultado<Alternativas>(false, "La alternativa que desea modificar no existe.", null);
                }
                //Si existe
                else
                {
                    //Valida que no modifiquen la Clave
                    if (iId != obj.ID_Alt)
                    {
                        return new Resultado<Alternativas>(false, "No puede modificar la clave de la Alternativa.", null);
                    }
                    else
                    {
                        //Actualiza el Usuario
                        bd.Entry(objAux).State = EntityState.Detached;
                        bd.Entry(obj).State = EntityState.Modified;
                        await bd.SaveChangesAsync();
                        return new Resultado<Alternativas>(true, "La Alternativa fue modificado con éxito.", obj);
                    }
                }
            }
            catch (Exception ex)
            {
                //Verifica si se produce error al consultar
                return new Resultado<Alternativas>(false, String.Format("Error al modificiar la Alternativa. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }
        //Delete: Borra una Alternativa Existente
        [HttpDelete("{iId}")]
        public async Task<ActionResult<Resultado<Alternativas>>> Delete(int iId)
        {
            try
            {
                //Verifica si el Usuario existe
                Alternativas objAux = await bd.Alternativas.Where(x => x.ID_Alt == iId).FirstOrDefaultAsync();

                //Si no existe
                if (objAux == null)
                {
                    return new Resultado<Alternativas>(false, "La Alternativa que desea borrar no existe.", null);
                }
                //Si existe
                else
                {
                    //Elimina el usuario
                    bd.Alternativas.Remove(objAux);
                    await bd.SaveChangesAsync();

                    return new CreatedAtRouteResult("GetAlternativa", new { iId = iId });
                }
            }
            catch (Exception ex)
            {
                //Verifica si se produce error al consultar
                return new Resultado<Alternativas>(false, String.Format("Error al borrar la Alternativa. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }
    }
}
