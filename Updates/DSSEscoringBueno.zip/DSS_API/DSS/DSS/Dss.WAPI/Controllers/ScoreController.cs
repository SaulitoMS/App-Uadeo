﻿using DSS.WAPI.Contexts;
using DSS.WAPI.Entities;
using DSS.WAPI.Util;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace DSS.WAPI.Controllers
{
    [Route("api/DSS/[controller]")]
    [ApiController]
    public class ScoresController : ControllerBase
    {
        private DssContext bd;

        // Inyeccion de dependencias
        public ScoresController(DssContext bd)
        {
            this.bd = bd;
        }

        //Get: Obtiene la lista de Score
        [HttpGet]
        public async Task<ActionResult<Resultado<IEnumerable<Scores>>>> Get()
        {
            try
            {
                IEnumerable<Scores> lstObj = await bd.Scores.ToListAsync();

                if (lstObj == null)
                {
                    return new Resultado<IEnumerable<Scores>>(false, "La lista de Score está vacía", null);
                }
                else
                {
                    return new Resultado<IEnumerable<Scores>>(true, "La lista de Score fue obtenida con exito", lstObj);
                }

            }
            catch (Exception ex)
            {
                return new Resultado<IEnumerable<Scores >>(false, String.Format("Erroe al consultar la lista de Score.Mensaje del Servidor:{0}", ex.Message), null);
            }

        }

        //Get(Id): Obtiene un Score por Id
        [HttpGet("{iId}", Name = "GetScores")]
        public async Task<ActionResult<Resultado<Scores>>> Get(int iId)
        {
            try
            {
                //Consulta el objeto
                Scores obj = await bd.Scores.Where(tbl => tbl.ID_Score == iId).FirstOrDefaultAsync();

                //Valida si lo encontró
                if (obj == null)
                    return new Resultado<Scores>(false, "El Score no se encontró", null);
                else
                    return new Resultado<Scores>(true, "El Score fue obtenido con éxito", obj);
            }
            catch (Exception ex)
            {
                //Verifica si se produce error
                return new Resultado<Scores>(false, String.Format("Error al consultar el Score. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }
        //Post: Agrega un Score nuevo
        [HttpPost]
        public async Task<ActionResult<Resultado<Scores>>> Post([FromBody] Scores obj)
        {
            try
            {
                //Consulta el objeto
                Scores objAux = await bd.Scores.Where(tbl => tbl.ID_Score == obj.ID_Score).FirstOrDefaultAsync();

                //Valida si existe
                if (obj == null)
                {
                    return new Resultado<Scores>(false, "El Score que desea registrar ya existe.", null);
                }
                else
                {
                    //Registra objeto
                    await bd.Scores.AddAsync(obj);
                    await bd.SaveChangesAsync();

                    Resultado<Scores> res = new Resultado<Scores>(true, "El Score fue registrado con éxito.", obj);
                    return new CreatedAtRouteResult("GetScore", new { iId = obj.ID_Score }, res);
                }
            }
            catch (Exception ex)
            {
                //Verifica si se produce error
                return new Resultado<Scores>(false, String.Format("Error al registrar el Score. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }
        //Put: Modifica un Score Existente
        [HttpPut("{iId}")]
        public async Task<ActionResult<Resultado<Scores>>> Put(int iId, [FromBody] Scores obj)
        {
            try
            {
                //Verifica si el Usuario existe
                Scores objAux = await bd.Scores.Where(x => x.ID_Score == iId).FirstOrDefaultAsync();

                //No existe
                if (obj == null)
                {
                    return new Resultado<Scores>(false, "El Score que desea modificar no existe.", null);
                }
                //Si existe
                else
                {
                    //Valida que no modifiquen la Clave
                    if (iId != obj.ID_Score)
                    {
                        return new Resultado<Scores>(false, "No puede modificar la clave del Score.", null);
                    }
                    else
                    {
                        //Actualiza el Usuario
                        bd.Entry(objAux).State = EntityState.Detached;
                        bd.Entry(obj).State = EntityState.Modified;
                        await bd.SaveChangesAsync();
                        return new Resultado<Scores>(true, "El Score fue modificado con éxito.", obj);
                    }
                }
            }
            catch (Exception ex)
            {
                //Verifica si se produce error al consultar
                return new Resultado<Scores>(false, String.Format("Error al modificiar el Score. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }


        //Delete: Borra un Score Existente
        [HttpDelete("{iId}")]
        public async Task<ActionResult<Resultado<Scores>>> Delete(int iId)
        {
            try
            {
                //Verifica si el Usuario existe
                Scores objAux = await bd.Scores.Where(x => x.ID_Score == iId).FirstOrDefaultAsync();

                //Si no existe
                if (objAux == null)
                {
                    return new Resultado<Scores>(false, "El Score que desea borrar no existe.", null);
                }
                //Si existe
                else
                {
                    //Elimina el usuario
                    bd.Scores.Remove(objAux);
                    await bd.SaveChangesAsync();

                    return new CreatedAtRouteResult("GetScore", new { iId = iId });
                }
            }
            catch (Exception ex)
            {
                //Verifica si se produce error al consultar
                return new Resultado<Scores>(false, String.Format("Error al borrar el Score. Mensaje del Servidor: {0}", ex.Message), null);
            }
        }
    }
}
