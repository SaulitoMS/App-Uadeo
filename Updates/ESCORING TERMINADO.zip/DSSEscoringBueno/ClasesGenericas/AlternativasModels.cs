﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DSSEscoringBueno.ClasesGenericas
{
    public class AlternativasModels
    {
        
        public int ID_Alt { get; set; }
        
        public string Nombre_Alt { get; set; }

        public string Descripcion_Alt { get; set; }

        
        public int ID_Proy { get; set; }
    }
}
